package com.graduation.test_two.Model;

public class Catagory {
     private  String Name , image ;

    public Catagory()
     {
     }

    public Catagory(String name, String image) {
        this.Name = name;
        this.image = image;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
