package com.graduation.test_two;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.graduation.test_two.Model.customer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class signup extends AppCompatActivity {
    private static final int RC_SIGN_IN = 234;
    GoogleSignInClient mGoogleSignInClient;
    View va;


    DatabaseReference myRef ;
    // Write a message to the database
    FirebaseDatabase database ;
    FirebaseAuth mAuth;

    private CheckBox agree;
    ProgressBar progressBar;
    private Button Register;
    private TextView login;
    private EditText textInputEditTextName;
    private EditText textInputEditTextEmail;
    private EditText textInputEditTextPassword;
    private EditText textInputEditTextConfirmPassword;
    private EditText textInputEditTextPhone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        getSupportActionBar().hide();



        Register = (Button) findViewById(R.id.register);
        login=(TextView) findViewById (R.id.iagreeto);
       // textInputEditTextPhone = (EditText) findViewById(R.id.phonenumber);
        textInputEditTextName = (EditText) findViewById(R.id.Name);
        textInputEditTextEmail = (EditText) findViewById(R.id.Email);
        textInputEditTextPassword = (EditText) findViewById(R.id.Password);
        textInputEditTextConfirmPassword = (EditText) findViewById(R.id.Confirm_Password);

        agree = findViewById(R.id.checkBox2);



//        Typeface face =Typeface.createFromAsset(getAssets(),"font/VastShadow-Regular.ttf");
//        Register.setTypeface(face);
//        login.setTypeface(face);
//        textInputEditTextName.setTypeface(face);
//        textInputEditTextEmail.setTypeface(face);
//        textInputEditTextPassword.setTypeface(face);
//        textInputEditTextPhone.setTypeface(face);
//        textInputEditTextConfirmPassword.setTypeface(face);
//        agree .setTypeface(face);


        myRef = database.getInstance().getReference("customer");
        mAuth=FirebaseAuth.getInstance();

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(signup.this, signin.class));
            }
        });





        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String email = textInputEditTextEmail.getText().toString().trim();
                final String password = textInputEditTextPassword.getText().toString().trim();
                final String name = textInputEditTextName.getText().toString().trim();
                final String confirmpassword = textInputEditTextConfirmPassword.getText().toString().trim();
                //final String phone = textInputEditTextPhone.getText().toString().trim();
                final String phone = null;
                if (name.isEmpty()) {
                    textInputEditTextName.setError("name is required");
                    textInputEditTextName.requestFocus();
                    return;
                }

                if (email.isEmpty()) {
                    textInputEditTextEmail.setError("Email is required");
                    textInputEditTextEmail.requestFocus();
                    return;
                }
//                if (phone.isEmpty() ||phone.length()!=10 || !phone.startsWith("05")) {
//                    textInputEditTextPhone.setError("Enter Valid Mobile Number");
//                    return;
//                }
               // if (TextUtils.isEmpty(email)) {
                 //   Toast.makeText(signup.this, "Email is required", Toast.LENGTH_SHORT).show();
                   // return;
                //}

//                if (TextUtils.isEmpty(password)) {
//                    Toast.makeText(signup.this, "passs is required", Toast.LENGTH_SHORT).show();
//                    return;
//                }
//                if (TextUtils.isEmpty(name)) {
//                    Toast.makeText(signup.this, "name is required", Toast.LENGTH_SHORT).show();
//                    return;
//                }
//                if (TextUtils.isEmpty(confirmpassword)) {
//                    Toast.makeText(signup.this, "confirm pass is required", Toast.LENGTH_SHORT).show();
//                    return;
//                }

                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    textInputEditTextEmail.setError("Please enter a valid email");
                    textInputEditTextEmail.requestFocus();
                    return;
                }

                if (password.isEmpty() || password.length() < 8  || !(password.matches(".*[0-9].*")) ||  !(password.matches(".*[A-Z].*") ||  password.matches(".*[a-z].*") )) {
                    textInputEditTextPassword.setError("password must be at least 8 (charcter , numeric)");
                    textInputEditTextPassword.requestFocus();
                    return;
                }

                if (confirmpassword.isEmpty() || password.length() < 8  || !(confirmpassword.matches(".*[0-9].*")) ||  !(confirmpassword.matches(".*[A-Z].*") ||  confirmpassword.matches(".*[a-z].*") )) {
                    textInputEditTextConfirmPassword.setError("password must be at least 8 (charcter , numeric)");
                    textInputEditTextConfirmPassword.requestFocus();
                    return;
                }


                    if (confirmpassword.isEmpty() ||confirmpassword.length() < 6  || !(confirmpassword.equals(password))) {

                    textInputEditTextConfirmPassword.setError("please Make sure your Password and Confirm Password are identical ");
                    textInputEditTextConfirmPassword.requestFocus();
                    return;
                }



                mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(signup.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                       // if (task.isSuccessful()) {

                            customer information = new customer(name, email, password, confirmpassword,phone);

                            database.getInstance().getReference("customer").child(mAuth.getInstance().getCurrentUser().getUid()).
                                    setValue(information).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {

                                    if(task.isSuccessful()){
                                        sendEmailVerification();
                                    }

                                    else{

                                        Snackbar.make(va, "Registration Failed! !!!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                                    }

                                }
                            });

                    }

                });

            }
        });



agree.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

        if(b)
        {
            Register.setVisibility(View.VISIBLE);
        }
        else
        {
            Register.setVisibility(View.INVISIBLE);
        }

                 }
        });


    }
    private void sendEmailVerification(){
        FirebaseUser firebaseUser = mAuth.getCurrentUser();
        if(firebaseUser!=null){
            firebaseUser.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()){
                        Toast.makeText(signup.this, "Successfully Registered, Verification mail sent!", Toast.LENGTH_SHORT).show();
                       // Snackbar.make("Successfully Registered, Verification mail sent!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                        startActivity(new Intent(signup.this, signin.class));
                        mAuth.signOut();
                        //finish();
                    }
                    else{
                     //  Snackbar.make(signup.this,"Verification mail has'nt been sent!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                        Toast.makeText(signup.this, "Verification mail has'nt been sent!", Toast.LENGTH_SHORT).show();

                    }
                }
            });
        }
    }


}