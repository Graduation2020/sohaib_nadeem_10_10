package com.graduation.test_two;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.graduation.test_two.Model.MainDishFood;
import com.graduation.test_two.ViewHolder.FoodViewHolder;
import com.mancj.materialsearchbar.MaterialSearchBar;
import com.rey.material.widget.EditText;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class Foodlist_one extends AppCompatActivity {


    private DatabaseReference foodlist;
    private FirebaseDatabase database;
    private RecyclerView recyclerView_menumaindish;//  private RecyclerView searchList;
    RecyclerView.LayoutManager layoutManager;

    private Button SearchBtn;
    private EditText inputText;
    private String SearchInput;


    FirebaseRecyclerAdapter<MainDishFood, FoodViewHolder> adapter;
    String Catagoryid = "";

    /*FirebaseRecyclerAdapter<MainDishFood, FoodViewHolder> searchAadpter;
    List<String> suggestlist=new ArrayList<>();
    MaterialSearchBar materialSearchBar;*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foodlist_one);
        getSupportActionBar().hide();

        foodlist = FirebaseDatabase.getInstance().getReference().child("Food");
        database= FirebaseDatabase.getInstance();

        recyclerView_menumaindish = findViewById(R.id.recycler_menu);
        recyclerView_menumaindish.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView_menumaindish.setLayoutManager(layoutManager);



        if (getIntent() != null)
            Catagoryid = getIntent().getStringExtra("CatagoryID");

        /*if (!Catagoryid.isEmpty() && Catagoryid != null) {
            LoadListFood(Catagoryid);
        }*/
        if (!Catagoryid.isEmpty() ) {
            LoadListFood(Catagoryid);
        }

       /* materialSearchBar = (MaterialSearchBar)findViewById(R.id.search_bar1);
        materialSearchBar.setHint("Enter FOOD Name");
        materialSearchBar.setLastSuggestions(suggestlist);
        materialSearchBar.setCardViewElevation(10);
        materialSearchBar.addTextChangeListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
List<String> suggest =
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });*/
       // loadsuggest();

        inputText = findViewById(R.id.search_product_name);
        SearchBtn = findViewById(R.id.search_btn);



        SearchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                SearchInput = inputText.getText().toString();
                Search();
            }
        });

    }





    private void Search() {
            //super.onStart();
            DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Food");

            FirebaseRecyclerOptions<MainDishFood> options = new FirebaseRecyclerOptions.Builder<MainDishFood>()
                            .setQuery(reference.orderByChild("Name").startAt(SearchInput), MainDishFood.class)
                            .build();

           adapter = new FirebaseRecyclerAdapter<MainDishFood, FoodViewHolder>(options) {
                        @Override
                        protected void onBindViewHolder(@NonNull FoodViewHolder holder, final int position, @NonNull final MainDishFood mainDishFood)
                        {
                         /*   holder.name.setText(model.getPname());
                            holder.txtProductDescription.setText(model.getDescription());
                            holder.txtProductPrice.setText("Price = " + model.getPrice() + "$");
                            Picasso.get().load(model.getImage()).into(holder.imageView);*/
                            holder.maindishfoodtype.setText(mainDishFood.getName());
                            Picasso.get().load(mainDishFood.getImage()).into( holder.maindishimageView);

//                            holder.itemView.setOnClickListener(new View.OnClickListener() {
//                                @Override
//                                public void onClick(View view)
//                                {
//                                    Intent intent = new Intent(SearchProductsActivity.this, ProductDetailsActivity.class);
//                                    intent.putExtra("pid", model.getPid());
//                                    startActivity(intent);
//                                }
//                            });

                            holder.itemView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    //Toast.makeText(Foodlist_one.this, ""+local.getName(), Toast.LENGTH_SHORT).show();

                                   // Toast.makeText(Foodlist_one.this,local.getName(),Toast.LENGTH_SHORT).show();

                                    Intent foodDetail = new Intent(Foodlist_one.this,Foodlist_one_details.class);
                                    foodDetail.putExtra("FoodId",adapter.getRef(position).getKey());
                                    startActivity(foodDetail);

                                }
                            });
                        }

                        @NonNull
                        @Override
                        public FoodViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.main_dish_items, parent, false);
                            FoodViewHolder holder = new FoodViewHolder(view);
                            return holder;

                        }
                    };

        recyclerView_menumaindish.setAdapter(adapter);
       // Log.d("TAG",""+adapter.getItemCount());
        adapter.startListening();

    }


    private void LoadListFood(String catagoryid) {

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Food");

//        FirebaseRecyclerOptions<MainDishFood> options = new FirebaseRecyclerOptions.Builder<MainDishFood>()
//                .setQuery(reference.orderByChild("MenuID").equalTo(catagoryid), MainDishFood.class)
//                .build();


        FirebaseRecyclerOptions<MainDishFood> options = new FirebaseRecyclerOptions.Builder<MainDishFood>()
                .setQuery(reference, MainDishFood.class)
                .build();


        // FirebaseRecyclerOptions<MainDishFood> options = new FirebaseRecyclerOptions.Builder<MainDishFood>().setQuery(foodlist.orderByChild("MenuID").equalTo(catagoryid), MainDishFood.class).build();
      //  FirebaseRecyclerOptions<MainDishFood> options = new FirebaseRecyclerOptions.Builder<MainDishFood>().setIndexQuery(foodlist, MainDishFood.class).build();
      // FirebaseRecyclerOptions<MainDishFood> options = new FirebaseRecyclerOptions.Builder<MainDishFood>().setQuery(foodlist, MainDishFood.class).build();

   adapter = new FirebaseRecyclerAdapter<MainDishFood, FoodViewHolder>(options) {
//  adapter = new FirebaseRecyclerAdapter<MainDishFood, FoodViewHolder>(MainDishFood.class,R.layout.main_dish_items,FoodViewHolder.class,foodlist.orderByChild("MenuID").equalTo(catagoryid)){

            // .orderByChild("MenuID").equalTo(catagoryid)

        @Override
        protected void onBindViewHolder(@NonNull FoodViewHolder foodViewHolder, final int POS, @NonNull MainDishFood mainDishFood) {


            foodViewHolder.maindishfoodtype.setText(mainDishFood.getName());
            Picasso.get().load(mainDishFood.getImage()).into(foodViewHolder.maindishimageView);
            final MainDishFood local = mainDishFood;

/*                foodViewHolder.setItemClickListner(new ItemClickListner() {
                    @Override
                    public void onClick(View view, int position, boolean isLong) {

                        Toast.makeText(Foodlist_one.this, ""+local.getName(), Toast.LENGTH_SHORT).show();
                    }
                });*/

            foodViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //Toast.makeText(Foodlist_one.this, ""+local.getName(), Toast.LENGTH_SHORT).show();

                    Toast.makeText(Foodlist_one.this,local.getName(),Toast.LENGTH_SHORT).show();

                    Intent foodDetail = new Intent(Foodlist_one.this,Foodlist_one_details.class);
                    foodDetail.putExtra("FoodId",adapter.getRef(POS).getKey());
                    startActivity(foodDetail);

                }
            });
        }

        @NonNull
        @Override
        public FoodViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.main_dish_items, parent, false);
            FoodViewHolder holder = new FoodViewHolder(view);
            return holder;

        }
    };

        recyclerView_menumaindish.setAdapter(adapter);
        Log.d("TAG",""+adapter.getItemCount());
        adapter.startListening();

    }

}











//    @Override
//    protected void onStart() {
//        super.onStart();
//        FirebaseRecyclerOptions<MainDishFood> options = new FirebaseRecyclerOptions.Builder<MainDishFood>().setQuery(foodlist, MainDishFood.class).build();
//
//
//        adapter = new FirebaseRecyclerAdapter<MainDishFood, FoodViewHolder>(options) {
//
//
//            @Override
//            protected void onBindViewHolder(@NonNull FoodViewHolder foodViewHolder, final int POS, @NonNull MainDishFood mainDishFood) {
//                foodViewHolder.maindishfoodtype.setText(mainDishFood.getName());
//                Picasso.get().load(mainDishFood.getImage()).into(foodViewHolder.maindishimageView);
//                final MainDishFood clickItem = mainDishFood;
//
////                foodViewHolder.setItemClickListner(new ItemClickListner() {
////                    @Override
////                    public void onClick(View view, int position, boolean isLong) {
////                        // get catagoryid and srnd to new activity
////                        Intent maindishlist = new Intent(Foodlist_one.this,Foodlist_one.class);
////
////                        // becuase catagoryid is key , so we just get key of this items
////                        maindishlist.putExtra("CatagoryID",adapter.getRef(POS).getKey());
////                        startActivity(maindishlist);
////                    }
////                });
//            }
//
//            @NonNull
//            @Override
//            public FoodViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.main_dish_items, parent, false);
//                FoodViewHolder holder = new FoodViewHolder(view);
//                return holder;
//
//            }
//        };
//
//        recyclerView_menumaindish.setAdapter(adapter);
//        adapter.startListening();
//
//
//    }