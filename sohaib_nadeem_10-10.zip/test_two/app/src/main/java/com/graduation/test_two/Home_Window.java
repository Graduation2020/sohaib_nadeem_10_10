package com.graduation.test_two;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import android.view.View;

import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.ui.AppBarConfiguration;

import com.google.android.material.navigation.NavigationView;
import com.graduation.test_two.fragments.HomeFragment;
import com.graduation.test_two.fragments.NearByFragment;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import de.hdodenhof.circleimageview.CircleImageView;

import android.view.Menu;
import android.app.FragmentManager;

import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;


public class Home_Window extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, BottomNavigationView.OnNavigationItemSelectedListener {
    private AppBarConfiguration mAppBarConfiguration;

    public Home_Window() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home__window);
        Toolbar toolbar = findViewById(R.id.toolbar);
        //toolbar.setTitle("Home");
        setSupportActionBar(toolbar);
        getSupportActionBar().hide();

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        View headerView = navigationView.getHeaderView(0);
        TextView username= headerView.findViewById(R.id.username);
        CircleImageView profieimage= headerView.findViewById(R.id.profile_image);
        username.setText("Nadeem Abu Al Arayes ");


        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(this);
        loadFragment(new HomeFragment());
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home__window, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        switch (item.getItemId()) {

            case R.id.navigation_home:

                loadFragment(new HomeFragment());
                Toast.makeText(Home_Window.this, "Homee ", Toast.LENGTH_SHORT).show();

                break;
            case R.id.navigation_nearby:
                loadFragment(new NearByFragment());
//                    FragmentManager fm1 = getFragmentManager();
//                    fm1.beginTransaction().replace(R.id.nav_host_fragment,new NearByFragment()).commit();
                Toast.makeText(Home_Window.this, "NearBy ", Toast.LENGTH_SHORT).show();

                break;

            case R.id.navigation_Kitchens:
                Intent intent = new Intent(Home_Window.this, Kitchens_List.class);
                startActivity(intent);
                Toast.makeText(Home_Window.this, "Welcome in Our Kitchens ", Toast.LENGTH_SHORT).show();
                break;



            case  R.id.nav_LogOut:
                    Intent intent1 = new Intent(Home_Window.this,Start.class);
                    startActivity(intent1);
                    Toast.makeText(Home_Window.this,"good Bya",Toast.LENGTH_SHORT).show();

        }

//        if(id == R.id.navigation_Kitchens){
//        Intent intent = new Intent(Home_Window.this,Kitchens_List.class);
//        startActivity(intent);
//        Toast.makeText(Home_Window.this,"Welcome in Our Kitchens ",Toast.LENGTH_SHORT).show();
//        }


      if (id == R.id.nav_Order) {

        }
        else if (id == R.id.nav_Favorite) {

        }
        else if (id == R.id.nav_coupons) {

        }
        else if (id == R.id.nav_payment) {

        }
//        else if (id == R.id.nav_LogOut) {
//
//            Intent intent = new Intent(Home_Window.this,Start.class);
//            startActivity(intent);
//            Toast.makeText(Home_Window.this,"good Bya",Toast.LENGTH_SHORT).show();
//
//        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        //return loadFragment(fragment);
        return true;
    }

    private void loadFragment(NearByFragment nearByFragment) {
    }


    private void loadFragment(Fragment fragment) {
        androidx.fragment.app.FragmentManager fm = getSupportFragmentManager();
        fm.beginTransaction().replace(R.id.nav_host_fragment, fragment)
                .commit();
    }
}
