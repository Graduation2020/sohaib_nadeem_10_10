package com.graduation.test_two.Prevalent;

import com.graduation.test_two.Model.customer;

public class Prevalent {

    public  static customer currentOnlineuser;
    public   static  final  String useremailkey= "useremail";
    public   static  final  String userpasswordkey= "userpassword";



}
