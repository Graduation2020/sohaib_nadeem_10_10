package com.graduation.test_two.fragments;

import androidx.fragment.app.Fragment;
import android.content.Context;
import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.graduation.test_two.R;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Created by Belal on 1/23/2018.
 */

public class KitchensFragment extends Fragment {

    public KitchensFragment() {
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
    }



    @Override
    public void onCreate(@androidx.annotation.Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @androidx.annotation.Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @androidx.annotation.Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        return view;
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }
}

