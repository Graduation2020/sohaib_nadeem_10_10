package com.graduation.test_two.Model;

public class MainDishFood {

   private String Name, image,description,price,discount, MenuID;


    public MainDishFood() {
    }


    public MainDishFood(String name, String image, String description, String price, String discount, String menuID) {
        Name = name;
        this.image = image;
        this.description = description;
        this.price = price;
        this.discount = discount;
        MenuID = menuID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    public String getMenuID() {
        return MenuID;
    }

    public void setMenuID(String menuID) {
        MenuID = menuID;
    }
}
