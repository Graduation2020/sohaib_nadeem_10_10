package com.graduation.test_two;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.graduation.test_two.Model.Catagory;
import com.graduation.test_two.ViewHolder.ProductViewHolder;
import com.squareup.picasso.Picasso;

public class Kitchens_List extends AppCompatActivity {
    private DatabaseReference productRef;
    private RecyclerView recyclerView_menu;
    RecyclerView.LayoutManager layoutManager;
    FirebaseRecyclerAdapter<Catagory, ProductViewHolder> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kitchens__list);
        getSupportActionBar().hide();
        recyclerView_menu= findViewById(R.id.recycler_menu);
        recyclerView_menu.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView_menu .setLayoutManager( layoutManager);
    }
    @Override
    protected void onStart() {
        super.onStart();
        productRef = FirebaseDatabase.getInstance().getReference().child("Catagory");
        FirebaseRecyclerOptions<Catagory> options= new FirebaseRecyclerOptions.Builder<Catagory>()
                .setQuery(productRef,Catagory.class).build();

        adapter = new FirebaseRecyclerAdapter<Catagory, ProductViewHolder>(options) {

            @Override
            protected void onBindViewHolder(@NonNull final ProductViewHolder holder, final int pos, @NonNull Catagory catagory) {
                final String menu_id = getRef(pos).getKey();

                holder.foodtype.setText(catagory.getName());
                Picasso.get().load(catagory.getImage()).into(holder.imageView);
                // final  Catagory clickItem = catagory;

                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        // get catagoryid and send to new activity
                        Intent maindishlist = new Intent(Kitchens_List.this, Foodlist_one.class);

                        // becuase catagoryid is key , so we just get key of this items
                        maindishlist.putExtra("CatagoryID",adapter.getRef(pos).getKey());
                        //maindishlist.putExtra("CatagoryID",menu_id);
                        startActivity(maindishlist);
                    }
                });


//                        if ( holder.foodtype.equals("Appetizer")  ) {
//                            holder.itemView.setOnClickListener(new View.OnClickListener() {
//                                @Override
//                                public void onClick(View v) {
//                                    // get catagoryid and send to new activity
//                                    Intent maindishlist = new Intent(Home_Window.this, signin.class);
//
//                                    // becuase catagoryid is key , so we just get key of this items
////                                  maindishlist.putExtra("CatagoryID",adapter.getRef(pos).getKey());
//                                    //maindishlist.putExtra("CatagoryID",menu_id);
//                                    startActivity(maindishlist);
//                                }
//                            });
//                        }

//                        holder.itemView.setItemClickListner(new ItemClickListner() {
//                            @Override
//                            public void onClick(View view, int position, boolean isLong) {
//                                // get catagoryid and srnd to new activity
//                                Intent maindishlist = new Intent(Home_Window.this,Foodlist_one.class);
//
//                                // becuase catagoryid is key , so we just get key of this items
//                             //   maindishlist.putExtra("CatagoryID",adapter.getRef(i).getKey());
//                                 startActivity(maindishlist);
//                            }
//                        });

            }

            @NonNull
            @Override
            public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_items_layout,parent,false);
                ProductViewHolder holder = new ProductViewHolder(view);
                return  holder;

            }



        };

        recyclerView_menu.setAdapter(adapter);
        adapter.startListening();


    }
}
