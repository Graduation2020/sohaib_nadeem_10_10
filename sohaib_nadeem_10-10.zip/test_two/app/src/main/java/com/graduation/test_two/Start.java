package com.graduation.test_two;

import androidx.appcompat.app.AppCompatActivity;
import io.paperdb.Paper;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;
import com.graduation.test_two.Prevalent.Prevalent;

public class Start extends AppCompatActivity {
    Button SignIn, SignUp;
    FirebaseAuth mAuth;
    View v;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        getSupportActionBar().hide();
        SignIn = (Button) findViewById(R.id.join_now);
        SignUp = (Button) findViewById(R.id.registernewuser);
        Paper.init(this);
//        Typeface face =Typeface.createFromAsset(getAssets(),"font/VastShadow-Regular.ttf");
//        SignIn.setTypeface(face);
//        SignUp.setTypeface(face);

SignIn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        startActivity(new Intent(Start.this, signin.class));
    }
});


        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Start.this, signup.class));
            }
        });


        String emailkey = Paper.book().read(Prevalent.useremailkey);
        String passwordkey = Paper.book().read(Prevalent.userpasswordkey);



        if(emailkey !="" && passwordkey!="" )
        {
            if(!TextUtils.isEmpty(emailkey) && !TextUtils.isEmpty(passwordkey)){


            }
        }
    }

}
